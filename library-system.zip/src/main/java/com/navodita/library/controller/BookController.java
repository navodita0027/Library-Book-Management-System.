package com.navodita.library.controller;

import com.navodita.library.dto.BookDto;
import com.navodita.library.dto.PagedResponse;
import com.navodita.library.entity.Book;
import com.navodita.library.exception.ApiException;
import com.navodita.library.repository.BorrowRecordRepository;
import com.navodita.library.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {
    private final BookService bookService;
    private final BorrowRecordRepository recordRepository;

    @PostMapping
    public ResponseEntity<BookDto> create(@RequestBody BookDto dto) {
        if (dto.getTitle() == null) throw new ApiException("Title required");
        if (dto.getTotalCopies() <=0 ) throw new ApiException("Total copies must be > 0");
        if (dto.getAvailableCopies() < 0) dto.setAvailableCopies(dto.getTotalCopies());
        var b = bookService.createOrAddCopies(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(b));
    }

    @GetMapping
    public ResponseEntity<PagedResponse<BookDto>> list(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Boolean available,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title,asc") String sort
    ) {
        String[] s = sort.split(",");
        Sort.Direction dir = s.length>1 && s[1].equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Sort sortObj = Sort.by(dir, s[0]);
        Page<Book> p = bookService.list(category, available, page, size, sortObj);

        // apply simple filters
        List<Book> filtered = p.getContent().stream()
                .filter(b -> category==null || category.equalsIgnoreCase(b.getCategory()))
                .filter(b -> available==null || b.isAvailable()==available)
                .collect(Collectors.toList());

        var resp = PagedResponse.<BookDto>builder()
                .content(filtered.stream().map(this::toDto).collect(Collectors.toList()))
                .page(p.getNumber())
                .size(p.getSize())
                .totalElements(p.getTotalElements())
                .totalPages(p.getTotalPages())
                .build();
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BookDto> update(@PathVariable UUID id, @RequestBody BookDto dto) {
        var b = bookService.update(id, dto);
        return ResponseEntity.ok(toDto(b));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        long active = recordRepository.countTotalBorrowedByBook(id); // counts total borrows; ideally count active
        bookService.softDelete(id, active);
        return ResponseEntity.noContent().build();
    }

    private BookDto toDto(Book b) {
        return BookDto.builder()
                .id(b.getId())
                .title(b.getTitle())
                .author(b.getAuthor())
                .category(b.getCategory())
                .isAvailable(b.isAvailable())
                .totalCopies(b.getTotalCopies())
                .availableCopies(b.getAvailableCopies())
                .build();
    }
}
