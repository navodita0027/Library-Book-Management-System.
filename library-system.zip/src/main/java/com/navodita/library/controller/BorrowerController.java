package com.navodita.library.controller;

import com.navodita.library.entity.BorrowRecord;
import com.navodita.library.entity.Borrower;
import com.navodita.library.exception.ApiException;
import com.navodita.library.repository.BorrowRecordRepository;
import com.navodita.library.service.BorrowerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/borrowers")
@RequiredArgsConstructor
public class BorrowerController {
    private final BorrowerService borrowerService;
    private final BorrowRecordRepository recordRepository;

    @PostMapping
    public ResponseEntity<Borrower> register(@RequestBody Borrower b) {
        if (b.getName() == null || b.getEmail() == null) throw new ApiException("Name and email required");
        return ResponseEntity.status(HttpStatus.CREATED).body(borrowerService.register(b));
    }

    @GetMapping("/{id}/records")
    public ResponseEntity<List<BorrowRecord>> records(@PathVariable UUID id) {
        var list = recordRepository.findByBorrowerId(id);
        return ResponseEntity.ok(list);
    }

    @GetMapping("/overdue")
    public ResponseEntity<List<Borrower>> overdue() {
        var overdueRecords = recordRepository.findOverdue(java.time.LocalDate.now());
        var borrowers = overdueRecords.stream().map(BorrowRecord::getBorrower).distinct().toList();
        return ResponseEntity.ok(borrowers);
    }
}
