package com.navodita.library.controller;

import com.navodita.library.dto.BorrowRecordDto;
import com.navodita.library.dto.BorrowRequestDto;
import com.navodita.library.dto.ReturnRequestDto;
import com.navodita.library.entity.BorrowRecord;
import com.navodita.library.service.BorrowService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
public class BorrowController {
    private final BorrowService borrowService;

    @PostMapping("/borrow")
    public ResponseEntity<BorrowRecordDto> borrow(@RequestBody BorrowRequestDto req) {
        BorrowRecord rec = borrowService.borrow(req);
        return ResponseEntity.ok(toDto(rec));
    }

    @PostMapping("/return")
    public ResponseEntity<BorrowRecordDto> returnBook(@RequestBody ReturnRequestDto req) {
        BorrowRecord rec = borrowService.returnBook(req);
        return ResponseEntity.ok(toDto(rec));
    }

    @GetMapping("/records/active")
    public ResponseEntity<List<BorrowRecordDto>> active() {
        return ResponseEntity.ok(borrowService.getActiveRecords().stream().map(this::toDto).collect(Collectors.toList()));
    }

    private BorrowRecordDto toDto(BorrowRecord r) {
        return BorrowRecordDto.builder()
                .id(r.getId())
                .bookId(r.getBook().getId())
                .borrowerId(r.getBorrower().getId())
                .borrowDate(r.getBorrowDate())
                .dueDate(r.getDueDate())
                .returnDate(r.getReturnDate())
                .fineAmount(r.getFineAmount())
                .active(r.isActive())
                .build();
    }
}
