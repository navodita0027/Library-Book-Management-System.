package com.navodita.library.config;

import com.navodita.library.entity.Book;
import com.navodita.library.entity.FinePolicy;
import com.navodita.library.repository.BookRepository;
import com.navodita.library.repository.FinePolicyRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SampleData {
    private final BookRepository bookRepository;
    private final FinePolicyRepository finePolicyRepository;

    @PostConstruct
    public void init() {
        if (bookRepository.count() == 0) {
            bookRepository.save(Book.builder()
                    .title("Clean Code")
                    .author("Robert C. Martin")
                    .category("Tech")
                    .totalCopies(3)
                    .availableCopies(3)
                    .isAvailable(true)
                    .build());
            bookRepository.save(Book.builder()
                    .title("Effective Java")
                    .author("Joshua Bloch")
                    .category("Tech")
                    .totalCopies(2)
                    .availableCopies(2)
                    .isAvailable(true)
                    .build());
        }
        if (finePolicyRepository.count() == 0) {
            finePolicyRepository.save(FinePolicy.builder().category("Tech").finePerDay(5.0).build());
            finePolicyRepository.save(FinePolicy.builder().category("Fiction").finePerDay(2.0).build());
        }
    }
}
