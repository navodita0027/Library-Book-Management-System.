package com.navodita.library.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "borrow_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BorrowRecord {
    @Id
    private UUID id = UUID.randomUUID();

    @ManyToOne(optional = false)
    private Book book;

    @ManyToOne(optional = false)
    private Borrower borrower;

    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private Double fineAmount;
    private boolean active = true;
}
