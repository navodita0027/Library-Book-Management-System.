package com.navodita.library.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "books")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Book {
    @Id
    private UUID id = UUID.randomUUID();

    private String title;
    private String author;
    private String category;
    private boolean isAvailable = true;
    private int totalCopies;
    private int availableCopies;
    private boolean deleted = false;
}
