package com.navodita.library.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "borrowers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Borrower {
    @Id
    private UUID id = UUID.randomUUID();

    private String name;
    private String email;

    @Enumerated(EnumType.STRING)
    private MembershipType membershipType;

    private int maxBorrowLimit;

    public enum MembershipType { BASIC, PREMIUM }
}
