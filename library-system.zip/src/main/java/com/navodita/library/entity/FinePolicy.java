package com.navodita.library.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "fine_policy")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class FinePolicy {
    @Id
    private UUID id = UUID.randomUUID();

    private String category;
    private Double finePerDay;
}
