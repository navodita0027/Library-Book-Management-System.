package com.navodita.library.repository;

import com.navodita.library.entity.Book;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface BookRepository extends JpaRepository<Book, UUID> {
    Optional<Book> findByTitleIgnoreCaseAndDeletedFalse(String title);
    Page<Book> findAllByDeletedFalse(Pageable pageable);
}
