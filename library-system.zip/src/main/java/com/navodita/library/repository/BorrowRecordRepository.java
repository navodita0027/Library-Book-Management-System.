package com.navodita.library.repository;

import com.navodita.library.entity.BorrowRecord;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Repository
public interface BorrowRecordRepository extends JpaRepository<BorrowRecord, UUID> {
    @Query("select r from BorrowRecord r where r.active = true")
    List<BorrowRecord> findAllActive();

    @Query("select r from BorrowRecord r where r.borrower.id = :borrowerId order by r.borrowDate desc")
    List<BorrowRecord> findByBorrowerId(java.util.UUID borrowerId);

    @Query("select r from BorrowRecord r where r.dueDate < :today and r.returnDate is null")
    List<BorrowRecord> findOverdue(LocalDate today);

    long countByBorrowerIdAndActiveTrue(UUID borrowerId);

    @Query("select count(r) from BorrowRecord r where r.book.id = :bookId")
    long countTotalBorrowedByBook(UUID bookId);
}
