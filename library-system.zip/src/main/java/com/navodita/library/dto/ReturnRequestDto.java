package com.navodita.library.dto;

import lombok.*;
import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ReturnRequestDto {
    private java.util.UUID borrowerId;
    private java.util.UUID bookId;
}
