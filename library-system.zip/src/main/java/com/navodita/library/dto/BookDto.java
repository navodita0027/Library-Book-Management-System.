package com.navodita.library.dto;

import lombok.*;

import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BookDto {
    private UUID id;
    private String title;
    private String author;
    private String category;
    private boolean isAvailable;
    private int totalCopies;
    private int availableCopies;
}
