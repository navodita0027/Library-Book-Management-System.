package com.navodita.library.dto;

import lombok.*;
import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BorrowRequestDto {
    private UUID borrowerId;
    private UUID bookId;
}
