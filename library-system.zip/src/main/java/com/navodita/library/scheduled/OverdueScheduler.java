package com.navodita.library.scheduled;

import com.navodita.library.service.BorrowService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OverdueScheduler {
    private final BorrowService borrowService;

    // Runs daily at 01:00 AM
    @Scheduled(cron = "0 0 1 * * ?")
    public void checkOverdue() {
        var overdue = borrowService.getOverdueRecords();
        if (!overdue.isEmpty()) {
            System.out.println("Overdue records found: " + overdue.size());
            // In a real app, notify borrowers or flag records. For demo we log.
        }
    }
}
