package com.navodita.library.exception;

public class ApiException extends RuntimeException {
    public ApiException(String message) { super(message); }
}
