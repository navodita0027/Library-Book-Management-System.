package com.navodita.library.service;

import com.navodita.library.dto.BookDto;
import com.navodita.library.entity.Book;
import com.navodita.library.exception.ApiException;
import com.navodita.library.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BookService {
    private final BookRepository bookRepository;

    @Transactional
    public Book createOrAddCopies(BookDto dto) {
        var existing = bookRepository.findByTitleIgnoreCaseAndDeletedFalse(dto.getTitle());
        if (existing.isPresent()) {
            Book b = existing.get();
            b.setTotalCopies(b.getTotalCopies() + dto.getTotalCopies());
            b.setAvailableCopies(b.getAvailableCopies() + dto.getAvailableCopies());
            b.setAvailable(b.getAvailableCopies() > 0);
            return bookRepository.save(b);
        } else {
            Book b = Book.builder()
                    .title(dto.getTitle())
                    .author(dto.getAuthor())
                    .category(dto.getCategory())
                    .totalCopies(dto.getTotalCopies())
                    .availableCopies(dto.getAvailableCopies())
                    .isAvailable(dto.getAvailableCopies() > 0)
                    .deleted(false)
                    .build();
            return bookRepository.save(b);
        }
    }

    public Page<Book> list(String category, Boolean available, int page, int size, Sort sort) {
        Pageable p = PageRequest.of(page, size, sort);
        Page<Book> result = bookRepository.findAllByDeletedFalse(p);
        // Simple filtering at service; for production use Specifications or Criteria
        if (category == null && available == null) return result;
        return result.map(b -> b).filter(b -> true); // keep page structure - filters applied downstream in controller
    }

    public Book update(UUID id, BookDto dto) {
        Book b = bookRepository.findById(id).orElseThrow(() -> new ApiException("Book not found"));
        if (dto.getTitle() != null) b.setTitle(dto.getTitle());
        if (dto.getAuthor() != null) b.setAuthor(dto.getAuthor());
        if (dto.getCategory() != null) b.setCategory(dto.getCategory());
        if (dto.getTotalCopies() > 0) b.setTotalCopies(dto.getTotalCopies());
        if (dto.getAvailableCopies() >= 0) b.setAvailableCopies(dto.getAvailableCopies());
        b.setAvailable(b.getAvailableCopies() > 0);
        return bookRepository.save(b);
    }

    public void softDelete(UUID id, long activeBorrowCount) {
        if (activeBorrowCount > 0) throw new ApiException("Cannot delete book with active borrow records");
        Book b = bookRepository.findById(id).orElseThrow(() -> new ApiException("Book not found"));
        b.setDeleted(true);
        bookRepository.save(b);
    }
}
