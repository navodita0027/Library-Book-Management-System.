package com.navodita.library.service;

import com.navodita.library.entity.Borrower;
import com.navodita.library.exception.ApiException;
import com.navodita.library.repository.BorrowerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BorrowerService {
    private final BorrowerRepository borrowerRepository;

    public Borrower register(Borrower b) {
        if (b.getMembershipType() == null) throw new ApiException("Membership type required");
        if (b.getMembershipType() == Borrower.MembershipType.BASIC) b.setMaxBorrowLimit(2);
        else b.setMaxBorrowLimit(5);
        return borrowerRepository.save(b);
    }

    public Borrower findById(UUID id) {
        return borrowerRepository.findById(id).orElseThrow(() -> new ApiException("Borrower not found"));
    }
}
