package com.navodita.library.service;

import com.navodita.library.dto.BorrowRequestDto;
import com.navodita.library.dto.ReturnRequestDto;
import com.navodita.library.entity.Book;
import com.navodita.library.entity.BorrowRecord;
import com.navodita.library.entity.Borrower;
import com.navodita.library.entity.FinePolicy;
import com.navodita.library.exception.ApiException;
import com.navodita.library.repository.BookRepository;
import com.navodita.library.repository.BorrowRecordRepository;
import com.navodita.library.repository.BorrowerRepository;
import com.navodita.library.repository.FinePolicyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BorrowService {
    private final BookRepository bookRepository;
    private final BorrowerRepository borrowerRepository;
    private final BorrowRecordRepository recordRepository;
    private final FinePolicyRepository finePolicyRepository;

    @Value("${library.defaultFinePerDay:5.0}")
    private double defaultFinePerDay;

    @Transactional
    public BorrowRecord borrow(BorrowRequestDto req) {
        Borrower borrower = borrowerRepository.findById(req.getBorrowerId())
                .orElseThrow(() -> new ApiException("Borrower not found"));

        long activeCount = recordRepository.countByBorrowerIdAndActiveTrue(borrower.getId());
        if (activeCount >= borrower.getMaxBorrowLimit()) {
            throw new ApiException("Borrow limit exceeded");
        }

        Book book = bookRepository.findById(req.getBookId())
                .orElseThrow(() -> new ApiException("Book not found"));

        if (book.isDeleted()) throw new ApiException("Book not available");
        if (book.getAvailableCopies() <= 0) throw new ApiException("No copies available");

        book.setAvailableCopies(book.getAvailableCopies() - 1);
        if (book.getAvailableCopies() == 0) book.setAvailable(false);
        bookRepository.save(book);

        BorrowRecord rec = BorrowRecord.builder()
                .book(book)
                .borrower(borrower)
                .borrowDate(LocalDate.now())
                .dueDate(LocalDate.now().plusDays(14))
                .active(true)
                .build();
        return recordRepository.save(rec);
    }

    @Transactional
    public BorrowRecord returnBook(ReturnRequestDto req) {
        List<BorrowRecord> list = recordRepository.findByBorrowerId(req.getBorrowerId());
        var recOpt = list.stream().filter(r -> r.isActive() && r.getBook().getId().equals(req.getBookId())).findFirst();
        if (recOpt.isEmpty()) throw new ApiException("No active borrow record found for this book and borrower");
        BorrowRecord rec = recOpt.get();

        rec.setReturnDate(LocalDate.now());
        rec.setActive(false);

        if (rec.getReturnDate().isAfter(rec.getDueDate())) {
            long daysLate = ChronoUnit.DAYS.between(rec.getDueDate(), rec.getReturnDate());
            double finePerDay = finePolicyRepository.findByCategory(rec.getBook().getCategory())
                    .map(FinePolicy::getFinePerDay).orElse(defaultFinePerDay);
            rec.setFineAmount(daysLate * finePerDay);
        } else {
            rec.setFineAmount(0.0);
        }

        Book book = rec.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        book.setAvailable(true);
        bookRepository.save(book);

        return recordRepository.save(rec);
    }

    public List<BorrowRecord> getActiveRecords() {
        return recordRepository.findAllActive();
    }

    public List<BorrowRecord> getOverdueRecords() {
        return recordRepository.findOverdue(LocalDate.now());
    }
}
